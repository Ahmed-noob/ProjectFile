﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace NBD.Views
{
    public static class HtmlHelperExtensions
    {
        public static HtmlString DisplayForPhone<TResult>(Expression<Func<Model, TResult>> expression, string model)
        {

            if (model == null)
            {
                return new HtmlString(string.Empty);
            }
            string formatted = model;
            if (model.Length == 10)
            {
                formatted = $"({model.Substring(0, 3)}) {model.Substring(3, 3)}-{model.Substring(6, 4)}";
            }
            else if (model.Length == 7)
            {
                formatted = $"{model.Substring(0, 3)}-{model.Substring(3, 4)}";
            }
            string s = $"<a href='tel:{model}'>{formatted}</a>";
            return new HtmlString(s);
        }
    }
}
