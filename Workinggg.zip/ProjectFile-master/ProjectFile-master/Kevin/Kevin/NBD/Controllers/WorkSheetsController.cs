﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NBD.Data;
using NBD.Models;
using NBD.ViewModels;

namespace NBD.Controllers
{
    public class WorkSheetsController : Controller
    {
        private readonly NaturalByDesignContext _context;

        public WorkSheetsController(NaturalByDesignContext context)
        {
            _context = context;
        }

        // GET: WorkSheets
        public async Task<IActionResult> Index()
        {
            var naturalByDesignContext = _context.WorkSheets.Include(w => w.personnel).Include(w => w.project);
            return View(await naturalByDesignContext.ToListAsync());
        }

        // GET: WorkSheets/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workSheet = await _context.WorkSheets
                .Include(w => w.personnel)
                .Include(w => w.project)
                .FirstOrDefaultAsync(m => m.ProjectID == id);
            if (workSheet == null)
            {
                return NotFound();
            }

            return View(workSheet);
        }

        // GET: WorkSheets/Create
        public IActionResult Create()
        {
            //WorkSheet project = new WorkSheet();
            //PopulateAssignedPersonnelData(project);
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFullName");
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName");
            return View();
        }

        // POST: WorkSheets/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProjectID,PersonnelID,Task,Hours")] WorkSheet workSheet)
        {
            if (ModelState.IsValid)
            {
                _context.Add(workSheet);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFullName", workSheet.PersonnelID);
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName", workSheet.ProjectID);
            return View(workSheet);
        }

        // GET: WorkSheets/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workSheet = await _context.WorkSheets.FindAsync(id);
            if (workSheet == null)
            {
                return NotFound();
            }
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFullName", workSheet.PersonnelID);
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName", workSheet.ProjectID);
            return View(workSheet);
        }

        // POST: WorkSheets/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProjectID,PersonnelID,Task,Hours")] WorkSheet workSheet)
        {
            if (id != workSheet.ProjectID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(workSheet);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WorkSheetExists(workSheet.ProjectID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFullName", workSheet.PersonnelID);
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName", workSheet.ProjectID);
            return View(workSheet);
        }

        // GET: WorkSheets/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var workSheet = await _context.WorkSheets
                .Include(w => w.personnel)
                .Include(w => w.project)
                .FirstOrDefaultAsync(m => m.ProjectID == id);
            if (workSheet == null)
            {
                return NotFound();
            }

            return View(workSheet);
        }

        // POST: WorkSheets/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var workSheet = await _context.WorkSheets.FindAsync(id);
            _context.WorkSheets.Remove(workSheet);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        //private void PopulateAssignedPersonnelData(WorkSheet project)
        //{
        //    var allpersonnels = _context.Personnels;
        //    var propersonnels = new HashSet<int>(project.PersonnelID.Select(b => b.PersonnelID));
        //    var selected = new List<OptionVM>();
        //    var available = new List<OptionVM>();
        //    foreach (var s in allpersonnels)
        //    {
        //        if (propersonnels.Contains(s.ID))
        //        {
        //            selected.Add(new OptionVM
        //            {
        //                ID = s.ID,
        //                DisplayText = s.PersonnelFullName
        //            });
        //        }
        //        else
        //        {
        //            available.Add(new OptionVM
        //            {
        //                ID = s.ID,
        //                DisplayText = s.PersonnelFullName
        //            });
        //        }
        //    }

        //    ViewData["selOpts"] = new MultiSelectList(selected.OrderBy(s => s.DisplayText), "ID", "DisplayText");
        //    ViewData["availOpts"] = new MultiSelectList(available.OrderBy(s => s.DisplayText), "ID", "DisplayText");
        //}

        //private void UpdateProjectPersonnels(string[] selectedPerson, Project projectToUpdate)
        //{
        //    if (selectedPerson == null)
        //    {
        //        projectToUpdate.teams = new List<ProjectPersonnel>();
        //        return;
        //    }

        //    var selectedPersonssHS = new HashSet<string>(selectedPerson);
        //    var docPersonels = new HashSet<int>(projectToUpdate.teams.Select(b => b.PersonnelID));
        //    foreach (var s in _context.Personnels)
        //    {
        //        if (selectedPersonssHS.Contains(s.ID.ToString()))
        //        {
        //            if (!docPersonels.Contains(s.ID))
        //            {
        //                projectToUpdate.teams.Add(new ProjectPersonnel
        //                {
        //                    PersonnelID = s.ID,
        //                    ProjectID = projectToUpdate.ID
        //                });
        //            }
        //        }
        //        else
        //        {
        //            if (docPersonels.Contains(s.ID))
        //            {
        //                ProjectPersonnel specToRemove = projectToUpdate.teams.SingleOrDefault(d => d.PersonnelID == s.ID);
        //                _context.Remove(specToRemove);
        //            }
        //        }
        //    }
        //}
        private bool WorkSheetExists(int id)
        {
            return _context.WorkSheets.Any(e => e.ProjectID == id);
        }
    }
}
