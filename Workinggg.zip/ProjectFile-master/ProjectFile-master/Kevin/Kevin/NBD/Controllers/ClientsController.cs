﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NBD.Data;
using NBD.Models;

namespace NBD.Controllers
{
    //[Authorize(Roles = "Admin")]
    public class ClientsController : Controller
    {
        private readonly NaturalByDesignContext _context;

        public ClientsController(NaturalByDesignContext context)
        {
            _context = context;
        }
       
        // GET: Clients
        public async Task<IActionResult> Index(
            string actionButton,
            string SearchString,
            string sortDirection = "asc", 
            string sortField = "ClientName")
        {
            var clients = from cp in _context.Client
                .Include(c => c.projects)
                          select cp;

            if (!String.IsNullOrEmpty(SearchString))
            {
                clients = clients.Where(c => c.ClientName.ToUpper().Contains(SearchString.ToUpper())
                                       );
                ViewData["Filtering"] = " show";
            }
            //
            if (!String.IsNullOrEmpty(actionButton))
            {
                if (actionButton != "Filter")
                {
                    if (actionButton == sortField)
                    {
                        sortDirection = sortDirection == "asc" ? "desc" : "asc";
                    }
                    sortField = actionButton;
                }
            }
            //
         

            if (sortField == "Address")
            {
                if (sortDirection == "asc")
                {
                    clients = clients
                    .OrderByDescending(c => c.ClientAddress);
                }
                else
                {
                    clients = clients
                        .OrderBy(c => c.ClientAddress);
                }
            }

            else if (sortField == "Phone Num")
            {
                if (sortDirection == "asc")
                {
                    clients = clients
                    .OrderByDescending(c => c.ClientContact);
                }
                else
                {
                    clients = clients
                        .OrderBy(c => c.ClientContact);
                }
            }
            else if (sortField == "Representative")
            {
                if (sortDirection == "asc")
                {
                    clients = clients
                    .OrderByDescending(c => c.ClientRepresentative);
                }
                else
                {
                    clients = clients
                        .OrderBy(c => c.ClientRepresentative);
                }
            }
            else 
            {
                if (sortDirection == "asc")
                {
                    clients = clients
                        .OrderByDescending(c => c.ClientName);
                }
                else
                {
                    clients = clients
                        .OrderBy(c => c.ClientName);
                }

            }
            ViewData["sortField"] = sortField;
            ViewData["sortDirection"] = sortDirection;

            return View(await clients.ToListAsync());
        }

        // GET: Clients/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var client = await _context.Client
                .Include(c => c.projects)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (client == null)
            {
                return NotFound();
            }

            return View(client);
        }

        // GET: Clients/Create
        public IActionResult Create()
        {
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID", "ProjectName");
            return View();
        }

        // POST: Clients/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,ClientName,ClientAddress,ClientCity,ClientContact,ClientRepresentative,ClientRole,ProjectId")] Client client)
        {
            if (ModelState.IsValid)
            {
                _context.Add(client);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID");
            return View(client);
        }

        // GET: Clients/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var client = await _context.Client.FindAsync(id);
            if (client == null)
            {
                return NotFound();
            }
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID");
            return View(client);
        }

        // POST: Clients/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,ClientName,ClientAddress,ClientCity,ClientContact,ClientRepresentative,ClientRole,ProjectId")] Client client)
        {
            if (id != client.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(client);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClientExists(client.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID");
            return View(client);
        }

        // GET: Clients/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var client = await _context.Client
                .Include(c => c.projects)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (client == null)
            {
                return NotFound();
            }

            return View(client);
        }

        // POST: Clients/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var client = await _context.Client.FindAsync(id);
            _context.Client.Remove(client);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        //private SelectList ClientSelectList(int? selectedId)
        //{
        //    return new SelectList(_context.Client
        //        .OrderBy(d => d.ClientName), "ID", "FormalName", selectedId);
        //}
        //[HttpGet]
        //public JsonResult GetClients(int? id)
        //{
        //    return Json(ClientSelectList(id));
        //}
        //private void PopulateDropDownLists(Client client = null)
        //{
        //    ViewData["ID"] = ClientSelectList(client?.ID);
            
        //}

        private bool ClientExists(int id)
        {
            return _context.Client.Any(e => e.ID == id);
        }
    }
}
