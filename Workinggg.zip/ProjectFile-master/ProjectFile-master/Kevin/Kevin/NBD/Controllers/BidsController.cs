﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NBD.Data;
using NBD.Models;

namespace NBD.Controllers
{
    public class BidsController : Controller
    {
        private readonly NaturalByDesignContext _context;

        public BidsController(NaturalByDesignContext context)
        {
            _context = context;
        }

        // GET: Bids
        public async Task<IActionResult> Index(String MinDate,String MaxDate, 
            string SearchString, 
            string actionButton, 
            string sortDirection = "asc",
            string sortField = "ClientName")
        {

            var bids = from c in _context.Bid
                       //.Include(c => c.bidDate)
                       .Include(c => c.project)
                       select c;

            ViewData["Filtering"] = ""; //Assume not filtering....
            //Search by project Name....

            if (!String.IsNullOrEmpty(SearchString))
            {
                bids = bids.Where(c => c.project.ProjectName.ToUpper().Contains(SearchString.ToUpper()));

                ViewData["Filtering"] = " show";
            }

            //Min and max date
            if (!String.IsNullOrEmpty(MinDate))
            {
                bids = bids.Where(c => Convert.ToDateTime(c.BidDate) >= Convert.ToDateTime(MinDate));
                if (!String.IsNullOrEmpty(MaxDate))
                {
                    bids = bids.Where(c => Convert.ToDateTime(c.BidDate) <= Convert.ToDateTime(MaxDate));
                }
            }
            else if (String.IsNullOrEmpty(MinDate) && !String.IsNullOrEmpty(MaxDate))
            {
                bids = bids.Where(c => Convert.ToDateTime(c.BidDate) <= Convert.ToDateTime(MaxDate));
            }


            if (!String.IsNullOrEmpty(actionButton))
            {
                if (actionButton != "Filter")
                {
                    if (actionButton == sortField)
                    {
                        sortDirection = sortDirection == "asc" ? "desc" : "asc";
                    }
                    sortField = actionButton;
                }
            }

          
            if (sortField == "Bid Date")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.BidDate);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.BidDate);
                }
            }
            else if (sortField == "NBD Approved")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.NBDApprovedFlag);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c);
                }
            }
            else if (sortField == "Client Approved")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.ClientApprovedFlag);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c);
                }
            }
            else if (sortField == "Est Hours")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.Esthours);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.Esthours);
                }
            }
            else if (sortField == "Est Production Hours")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.EstProdWrkhours);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.EstProdWrkhours);
                }
            }
            else if (sortField == "Est Design Hours")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.EstDesignhours);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.EstDesignhours);
                }
            }
            else if (sortField == "Est Start Date")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.BidEstStartDate);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.BidEstStartDate);
                }
            }
            else if (sortField == "Est End Date")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.BidEstEndDate);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.BidEstEndDate);
                }
            }
            else if (sortField == "Project Name")
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                    .OrderByDescending(c => c.project);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.project);
                }
            }

           else 
            {
                if (sortDirection == "asc")
                {
                    bids = bids
                        .OrderByDescending(c => c.BidEstAmt);
                }
                else
                {
                    bids = bids
                        .OrderBy(c => c.BidEstAmt);
                }
            }

            ViewData["sortField"] = sortField;
            ViewData["sortDirection"] = sortDirection;

            return View(await bids.ToListAsync());
        }

        // GET: Bids/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bid = await _context.Bid
                .Include(b => b.project)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (bid == null)
            {
                return NotFound();
            }

            return View(bid);
        }

        // GET: Bids/Create
        public IActionResult Create()
        {
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID", "ProjectName");
            return View();
        }

        // POST: Bids/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,BidEstAmt,BidDate,NBDApprovedFlag,ClientApprovedFlag,Esthours,EstProdWrkhours,EstDesignhours,BidEstStartDate,BidEstEndDate,ProjectId")] Bid bid)
        {
            if (ModelState.IsValid)
            {
                _context.Add(bid);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID", "ProjectName", bid.ProjectId);
            return View(bid);
        }

        // GET: Bids/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bid = await _context.Bid.FindAsync(id);
            if (bid == null)
            {
                return NotFound();
            }
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID", "ProjectName", bid.ProjectId);
            return View(bid);
        }

        // POST: Bids/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,BidEstAmt,BidDate,NBDApprovedFlag,ClientApprovedFlag,Esthours,EstProdWrkhours,EstDesignhours,BidEstStartDate,BidEstEndDate,ProjectId")] Bid bid)
        {
            if (id != bid.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(bid);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BidExists(bid.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ProjectId"] = new SelectList(_context.Project, "ID", "ProjectName", bid.ProjectId);
            return View(bid);
        }

        // GET: Bids/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bid = await _context.Bid
                .Include(b => b.project)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (bid == null)
            {
                return NotFound();
            }

            return View(bid);
        }

        // POST: Bids/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var bid = await _context.Bid.FindAsync(id);
            _context.Bid.Remove(bid);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BidExists(int id)
        {
            return _context.Bid.Any(e => e.ID == id);
        }
    }
}
