﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NBD.Data;
using NBD.Models;

namespace NBD.Controllers
{
    public class PersonnelsController : Controller
    {
        private readonly NaturalByDesignContext _context;

        public PersonnelsController(NaturalByDesignContext context)
        {
            _context = context;
        }

        // GET: Personnels
        public async Task<IActionResult> Index()
        {
            PopulateDropDownLists();
            return View(await _context.Personnels.ToListAsync());
        }

        // GET: Personnels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personnel = await _context.Personnels
                .FirstOrDefaultAsync(m => m.ID == id);
            if (personnel == null)
            {
                return NotFound();
            }

            return View(personnel);
        }

        // GET: Personnels/Create
        public IActionResult Create()
        {
            Personnel personnel = new Personnel();
            //PopulateAssignedPersonnelData(project);
            ViewData["RoleID"] = new SelectList(_context.Role, "ID", "RoleName");
            return View();
        }

        // POST: Personnels/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,PersonnelFirstName,PersonnelMiddleName,PersonnelLastName")] Personnel personnel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(personnel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["RoleID"] = new SelectList(_context.Role, "ID", "RoleName", personnel.RoleID);

            return View(personnel);
        }

        // GET: Personnels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personnel = await _context.Personnels.FindAsync(id);
            if (personnel == null)
            {
                return NotFound();
            }
            ViewData["RoleID"] = new SelectList(_context.Role, "ID", "RoleName", personnel.RoleID);

            return View(personnel);
        }

        // POST: Personnels/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,PersonnelFirstName,PersonnelMiddleName,PersonnelLastName,Address,Email,PersonnelPhone,Role,Team,status,PayrateCPH,PayratePPH")] Personnel personnel)
        {
            if (id != personnel.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(personnel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PersonnelExists(personnel.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["RoleID"] = new SelectList(_context.Role, "ID", "RoleName", personnel.RoleID);

            return View(personnel);
        }

        // GET: Personnels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var personnel = await _context.Personnels
                .FirstOrDefaultAsync(m => m.ID == id);
            if (personnel == null)
            {
                return NotFound();
            }

            return View(personnel);
        }

        // POST: Personnels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var personnel = await _context.Personnels.FindAsync(id);
            _context.Personnels.Remove(personnel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        private void PopulateDropDownLists(Personnel personnel = null)
        {
            ViewData["RoleID"] = new SelectList(_context.Role, "ID", "RoleName", personnel?.RoleID);
            //ViewData["ClientID"] =new SelectList(_context.Client
            //   .OrderBy(c => c.ClientName)
            //   .ThenBy(c => c.ClientRepresentative), "ID", "ClientID", project?.ClientID);

        }
        private bool PersonnelExists(int id)
        {
            return _context.Personnels.Any(e => e.ID == id);
        }
    }
}
