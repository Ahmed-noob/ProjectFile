﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using NBD.Data;
using NBD.Models;
using NBD.ViewModels;

namespace NBD.Controllers
{
    public class ProjectsController : Controller
    {
        private readonly NaturalByDesignContext _context;

        public ProjectsController(NaturalByDesignContext context)
        {
            _context = context;
        }

        // GET: Projects
        public async Task<IActionResult> Index(int? ClientID,
            string SearchString,
             string actionButton,
            string sortDirection = "asc",
            string sortField = "ProjectName")
        {
            PopulateDropDownLists();
            ViewData["Filtering"] = "";

            var projects = from p in _context.Project
                .Include(p => p.client)
                .Include(p => p.teams).ThenInclude(p => p.personnel)
                           select p;

            if (ClientID.HasValue)
            {
                projects = projects.Where(p => p.ClientID == ClientID);
                ViewData["Filtering"] = " show";
            }
            //if (PersonnelID.HasValue)
            //{
            //    projects = projects.Where(p => p.teams.Any(c => c.PersonnelID == PersonnelID));
            //    ViewData["Filtering"] = " show";
            //}

            if (!String.IsNullOrEmpty(SearchString))
            {
                projects = projects.Where(p => p.ProjectName.ToUpper().Contains(SearchString.ToUpper())
                                       || p.ProjectSite.ToUpper().Contains(SearchString.ToUpper()));
                ViewData["Filtering"] = " show";
            }


            if (!String.IsNullOrEmpty(actionButton))
            {
                if (actionButton != "Filter")
                {
                    if (actionButton == sortField)
                    {
                        sortDirection = sortDirection == "asc" ? "desc" : "asc";
                    }
                    sortField = actionButton;
                }
            }

            if (sortField == "Site")
            {
                if (sortDirection == "asc")
                {
                    projects = projects
                    .OrderByDescending(p => p.ProjectSite);
                }
                else
                {
                    projects = projects
                        .OrderBy(p => p.ProjectSite);
                }
            }
            else if (sortField == "Act Begin Date")
            {
                if (sortDirection == "asc")
                {
                    projects = projects
                    .OrderByDescending(p => p.ProjectActBeginDate);
                }
                else
                {
                    projects = projects
                        .OrderBy(p => p.ProjectActBeginDate);
                }
            }

            else if (sortField == "Act End Date")
            {
                if (sortDirection == "asc")
                {
                    projects = projects
                   .OrderByDescending(p => p.ProjectActEndDate);
                }
                else
                {
                    projects = projects
                       .OrderBy(p => p.ProjectActEndDate);
                }
            }
           
            else
            {
                if (sortDirection == "asc")
                {
                    projects = projects
                    .OrderByDescending(p => p.ProjectName);
                }
                else
                {
                    projects = projects
                         .OrderBy(p => p.ProjectName);
                }

            }
            ViewData["sortField"] = sortField;
            ViewData["sortDirection"] = sortDirection;

            return View(await projects.ToListAsync());
        }
            // GET: Projects/Details/5
            public async Task<IActionResult> Details(int? id)
                
        {
            if (id == null)
            {
                return NotFound();
            }

            var project = await _context.Project
                .Include(p => p.client)
                .Include(p => p.bids)
                .Include(p => p.teams)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }

        // GET: Projects/Create
        public IActionResult Create()
        {
            Project project = new Project();
            PopulateAssignedPersonnelData(project);
            ViewData["ClientID"] = new SelectList(_context.Client, "ID", "ClientName");
            return View();
        }

        // POST: Projects/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,ProjectName,ProjectSite,ProjectActBeginDate,ProjectActEndDate,ClientID,ProjectBidActAmt")] Project project, string[] selectedOptions)
        {
            try
            {
                UpdateProjectPersonnels(selectedOptions, project);
                if (ModelState.IsValid)
                {
                    _context.Add(project);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (RetryLimitExceededException /* dex */)
            {
                ModelState.AddModelError("", "Unable to save changes after multiple attempts. Try again, and if the problem persists, see your system administrator.");
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Something went wrong in the database.");
            }
            PopulateAssignedPersonnelData(project);

            ViewData["ClientID"] = new SelectList(_context.Client, "ID", "ClientName", project.ClientID);
            return View(project);
        }

        // GET: Projects/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var project = await _context.Project
               .Include(p => p.client)
                .Include(p => p.teams).ThenInclude(p => p.personnel)
                .AsNoTracking()
                .SingleOrDefaultAsync(p => p.ID == id);

            //var project = await _context.Project.FindAsync(id);
            if (project == null)
            {
                return NotFound();
            }
            

            ViewData["ClientID"] = new SelectList(_context.Client, "ID", "ClientName", project.ClientID);
            PopulateAssignedPersonnelData(project);
            return View(project);
        }

        // POST: Projects/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,ProjectName,ProjectSite,ProjectActBeginDate,ProjectActEndDate,ClientID,ProjectBidActAmt")] Project project, string[] selectedOptions)
        {


            var projectToUpdate = await _context.Project
               .Include(p => p.client)
                .Include(p => p.teams).ThenInclude(p => p.personnel)
                .AsNoTracking()
                .SingleOrDefaultAsync(p => p.ID == id);

            if (id != projectToUpdate.ID)
            {
                return NotFound();
            }
            UpdateProjectPersonnels(selectedOptions, project);



            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(projectToUpdate);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProjectExists(projectToUpdate.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            PopulateAssignedPersonnelData(project);

            ViewData["ClientID"] = new SelectList(_context.Client, "ID", "ClientName", projectToUpdate.ClientID);
            return View(projectToUpdate);
        }

        // GET: Projects/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var project = await _context.Project
                .Include(p => p.client)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (project == null)
            {
                return NotFound();
            }

            return View(project);
        }

        // POST: Projects/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var project = await _context.Project.FindAsync(id);
            _context.Project.Remove(project);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        //private SelectList ClientSelectList(int? selectedId)
        //{
        //    return new SelectList(_context.Client
        //        .OrderBy(c => c.ClientName)
        //         .ThenBy(c => c.ClientRepresentative)
        //        , "ID", "ClientID", selectedId);
        //}
        //[HttpGet]

        //public JsonResult GenClients(int? id)
        //{
        //    return Json(ClientSelectList(id));
        //}
        private void PopulateDropDownLists(Project project = null)
        {
            ViewData["ClientID"] = new SelectList(_context.Client, "ID", "ClientName", project?.ClientID);
            //ViewData["ClientID"] =new SelectList(_context.Client
            //   .OrderBy(c => c.ClientName)
            //   .ThenBy(c => c.ClientRepresentative), "ID", "ClientID", project?.ClientID);

        }

        private void PopulateAssignedPersonnelData(Project project)
        {
            var allpersonnels = _context.Personnels;
            var propersonnels = new HashSet<int>(project.teams.Select(b => b.PersonnelID));
            var selected = new List<OptionVM>();
            var available = new List<OptionVM>();
            foreach (var s in allpersonnels)
            {
                if (propersonnels.Contains(s.ID))
                {
                    selected.Add(new OptionVM
                    {
                        ID = s.ID,
                        DisplayText = s.PersonnelFullName
                    });
                }
                else
                {
                    available.Add(new OptionVM
                    {
                        ID = s.ID,
                        DisplayText = s.PersonnelFullName
                    });
                }
            }

            ViewData["selOpts"] = new MultiSelectList(selected.OrderBy(s => s.DisplayText), "ID", "DisplayText");
            ViewData["availOpts"] = new MultiSelectList(available.OrderBy(s => s.DisplayText), "ID", "DisplayText");
        }

        private void UpdateProjectPersonnels(string[] selectedOptions, Project projectToUpdate)
        {
            if (selectedOptions == null)
            {
                projectToUpdate.teams = new List<ProjectPersonnel>();
                return;
            }

            var selectedPersonssHS = new HashSet<string>(selectedOptions);
            var docPersonels = new HashSet<int>(projectToUpdate.teams.Select(b => b.PersonnelID));
            foreach (var s in _context.Personnels)
            {
                if (selectedPersonssHS.Contains(s.ID.ToString()))
                {
                    if (!docPersonels.Contains(s.ID))
                    {
                        projectToUpdate.teams.Add(new ProjectPersonnel
                        {
                            PersonnelID = s.ID,
                            ProjectID = projectToUpdate.ID
                        });
                    }
                }
                else
                {
                    if (docPersonels.Contains(s.ID))
                    {
                        ProjectPersonnel specToRemove = projectToUpdate.teams.SingleOrDefault(d => d.PersonnelID == s.ID);
                        _context.Remove(specToRemove);
                    }
                }
            }
        }

        private bool ProjectExists(int id)
        {
            return _context.Project.Any(e => e.ID == id);
        }
    }
}
