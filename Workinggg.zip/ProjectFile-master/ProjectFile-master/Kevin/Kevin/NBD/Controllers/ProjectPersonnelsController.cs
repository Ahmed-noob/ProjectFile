﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NBD.Data;
using NBD.Models;

namespace NBD.Controllers
{
    public class ProjectPersonnelsController : Controller
    {
        private readonly NaturalByDesignContext _context;

        public ProjectPersonnelsController(NaturalByDesignContext context)
        {
            _context = context;
        }

        // GET: ProjectPersonnels
        public async Task<IActionResult> Index()
        {
            var naturalByDesignContext = _context.ProjectPersonnels.Include(p => p.personnel).Include(p => p.project);
            return View(await naturalByDesignContext.ToListAsync());
        }

        // GET: ProjectPersonnels/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var projectPersonnel = await _context.ProjectPersonnels
                .Include(p => p.personnel)
                .Include(p => p.project)
                .FirstOrDefaultAsync(m => m.ProjectID == id);
            if (projectPersonnel == null)
            {
                return NotFound();
            }

            return View(projectPersonnel);
        }

        // GET: ProjectPersonnels/Create
        public IActionResult Create()
        {
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFirstName");
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName");
            return View();
        }

        // POST: ProjectPersonnels/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProjectID,PersonnelID")] ProjectPersonnel projectPersonnel)
        {
            if (ModelState.IsValid)
            {
                _context.Add(projectPersonnel);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFirstName", projectPersonnel.PersonnelID);
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName", projectPersonnel.ProjectID);
            return View(projectPersonnel);
        }

        // GET: ProjectPersonnels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var projectPersonnel = await _context.ProjectPersonnels.FindAsync(id);
            if (projectPersonnel == null)
            {
                return NotFound();
            }
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFirstName", projectPersonnel.PersonnelID);
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName", projectPersonnel.ProjectID);
            return View(projectPersonnel);
        }

        // POST: ProjectPersonnels/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProjectID,PersonnelID")] ProjectPersonnel projectPersonnel)
        {
            if (id != projectPersonnel.ProjectID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(projectPersonnel);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProjectPersonnelExists(projectPersonnel.ProjectID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PersonnelID"] = new SelectList(_context.Personnels, "ID", "PersonnelFirstName", projectPersonnel.PersonnelID);
            ViewData["ProjectID"] = new SelectList(_context.Project, "ID", "ProjectName", projectPersonnel.ProjectID);
            return View(projectPersonnel);
        }

        // GET: ProjectPersonnels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var projectPersonnel = await _context.ProjectPersonnels
                .Include(p => p.personnel)
                .Include(p => p.project)
                .FirstOrDefaultAsync(m => m.ProjectID == id);
            if (projectPersonnel == null)
            {
                return NotFound();
            }

            return View(projectPersonnel);
        }

        // POST: ProjectPersonnels/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var projectPersonnel = await _context.ProjectPersonnels.FindAsync(id);
            _context.ProjectPersonnels.Remove(projectPersonnel);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProjectPersonnelExists(int id)
        {
            return _context.ProjectPersonnels.Any(e => e.ProjectID == id);
        }
    }
}
