﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class AddPK : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Project",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProjectName = table.Column<string>(maxLength: 50, nullable: false),
                    ProjectSite = table.Column<string>(maxLength: 500, nullable: false),
                    ProjectActStartDate = table.Column<DateTime>(nullable: false),
                    ProjectActEndDate = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Project", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "Bid",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    EstAmt = table.Column<float>(nullable: false),
                    bidDate = table.Column<DateTime>(nullable: false),
                    NBDApprovedFlag = table.Column<string>(maxLength: 1, nullable: false),
                    ClientApprovedFlag = table.Column<string>(maxLength: 1, nullable: false),
                    Esthours = table.Column<long>(nullable: false),
                    EstProdWrkhours = table.Column<long>(nullable: false),
                    EstDesignhours = table.Column<long>(nullable: false),
                    bidEstStartDate = table.Column<DateTime>(nullable: false),
                    bidEstEndDate = table.Column<DateTime>(nullable: false),
                    ProjectId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bid", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Bid_Project_ProjectId",
                        column: x => x.ProjectId,
                        principalTable: "Project",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Client",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ClientName = table.Column<string>(maxLength: 100, nullable: false),
                    ClientAddress = table.Column<string>(maxLength: 1000, nullable: false),
                    ClientCity = table.Column<string>(maxLength: 100, nullable: false),
                    ClientContact = table.Column<string>(maxLength: 100, nullable: false),
                    ClientRole = table.Column<string>(maxLength: 50, nullable: false),
                    Phone = table.Column<long>(nullable: false),
                    ProjectId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Client", x => x.ID);
                    table.ForeignKey(
                        name: "FK_Client_Project_ProjectId",
                        column: x => x.ProjectId,
                        principalTable: "Project",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Bid_ProjectId",
                table: "Bid",
                column: "ProjectId");

            migrationBuilder.CreateIndex(
                name: "IX_Client_ProjectId",
                table: "Client",
                column: "ProjectId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Bid");

            migrationBuilder.DropTable(
                name: "Client");

            migrationBuilder.DropTable(
                name: "Project");
        }
    }
}
