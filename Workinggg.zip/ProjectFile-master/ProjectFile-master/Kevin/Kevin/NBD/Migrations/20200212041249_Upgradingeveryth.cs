﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class Upgradingeveryth : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProjectEstBeginDate",
                table: "Project");

            migrationBuilder.DropColumn(
                name: "ProjectEstEndDate",
                table: "Project");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ProjectEstBeginDate",
                table: "Project",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ProjectEstEndDate",
                table: "Project",
                nullable: false,
                defaultValue: "");
        }
    }
}
