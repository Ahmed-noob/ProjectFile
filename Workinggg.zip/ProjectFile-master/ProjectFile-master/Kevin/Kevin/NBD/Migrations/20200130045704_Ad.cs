﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class Ad : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
