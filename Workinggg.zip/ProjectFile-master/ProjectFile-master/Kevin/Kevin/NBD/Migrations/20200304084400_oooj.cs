﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class oooj : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Personnels",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    PersonnelFirstName = table.Column<string>(maxLength: 20, nullable: false),
                    PersonnelMiddleName = table.Column<string>(maxLength: 20, nullable: true),
                    PersonnelLastName = table.Column<string>(maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Personnels", x => x.ID);
                });

            migrationBuilder.CreateTable(
                name: "ProjectPersonnels",
                columns: table => new
                {
                    ProjectID = table.Column<int>(nullable: false),
                    PersonnelID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjectPersonnels", x => new { x.ProjectID, x.PersonnelID });
                    table.ForeignKey(
                        name: "FK_ProjectPersonnels_Personnels_PersonnelID",
                        column: x => x.PersonnelID,
                        principalTable: "Personnels",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProjectPersonnels_Project_ProjectID",
                        column: x => x.ProjectID,
                        principalTable: "Project",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProjectPersonnels_PersonnelID",
                table: "ProjectPersonnels",
                column: "PersonnelID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ProjectPersonnels");

            migrationBuilder.DropTable(
                name: "Personnels");
        }
    }
}
