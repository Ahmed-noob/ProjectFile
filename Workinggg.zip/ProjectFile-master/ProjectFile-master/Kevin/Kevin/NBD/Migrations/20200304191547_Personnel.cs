﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class Personnel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "Personnels",
                maxLength: 500,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Personnels",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<float>(
                name: "PayrateCPH",
                table: "Personnels",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "PayratePPH",
                table: "Personnels",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<string>(
                name: "PersonnelPhone",
                table: "Personnels",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "Personnels",
                maxLength: 30,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Team",
                table: "Personnels",
                maxLength: 30,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "status",
                table: "Personnels",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Address",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "Email",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "PayrateCPH",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "PayratePPH",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "PersonnelPhone",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "Role",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "Team",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "status",
                table: "Personnels");
        }
    }
}
