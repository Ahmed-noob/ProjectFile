﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class usd : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<bool>(
                name: "NBDApprovedFlag",
                table: "Bid",
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 1);

            migrationBuilder.AlterColumn<bool>(
                name: "ClientApprovedFlag",
                table: "Bid",
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 1);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "NBDApprovedFlag",
                table: "Bid",
                maxLength: 1,
                nullable: false,
                oldClrType: typeof(bool));

            migrationBuilder.AlterColumn<string>(
                name: "ClientApprovedFlag",
                table: "Bid",
                maxLength: 1,
                nullable: false,
                oldClrType: typeof(bool));
        }
    }
}
