﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class Upgradingeverything : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "bidEstStartDate",
                table: "Bid",
                newName: "BidEstStartDate");

            migrationBuilder.RenameColumn(
                name: "bidEstEndDate",
                table: "Bid",
                newName: "BidEstEndDate");

            migrationBuilder.RenameColumn(
                name: "bidDate",
                table: "Bid",
                newName: "BidDate");

            migrationBuilder.RenameColumn(
                name: "EstAmt",
                table: "Bid",
                newName: "BidEstAmt");

            migrationBuilder.AlterColumn<string>(
                name: "ProjectActEndDate",
                table: "Project",
                nullable: true,
                oldClrType: typeof(DateTime));

            migrationBuilder.AlterColumn<string>(
                name: "ProjectActBeginDate",
                table: "Project",
                nullable: true,
                oldClrType: typeof(DateTime));

            migrationBuilder.AddColumn<float>(
                name: "ProjectBidActAmt",
                table: "Project",
                nullable: false,
                defaultValue: 0f);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProjectBidActAmt",
                table: "Project");

            migrationBuilder.RenameColumn(
                name: "BidEstStartDate",
                table: "Bid",
                newName: "bidEstStartDate");

            migrationBuilder.RenameColumn(
                name: "BidEstEndDate",
                table: "Bid",
                newName: "bidEstEndDate");

            migrationBuilder.RenameColumn(
                name: "BidDate",
                table: "Bid",
                newName: "bidDate");

            migrationBuilder.RenameColumn(
                name: "BidEstAmt",
                table: "Bid",
                newName: "EstAmt");

            migrationBuilder.AlterColumn<DateTime>(
                name: "ProjectActEndDate",
                table: "Project",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "ProjectActBeginDate",
                table: "Project",
                nullable: false,
                oldClrType: typeof(string),
                oldNullable: true);
        }
    }
}
