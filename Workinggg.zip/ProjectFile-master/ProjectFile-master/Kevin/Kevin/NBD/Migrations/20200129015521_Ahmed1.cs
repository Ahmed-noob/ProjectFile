﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class Ahmed1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Phone",
                table: "Client");

            migrationBuilder.RenameColumn(
                name: "ProjectActStartDate",
                table: "Project",
                newName: "ProjectActBeginDate");

            migrationBuilder.AddColumn<string>(
                name: "ProjectEstBeginDate",
                table: "Project",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ProjectEstEndDate",
                table: "Project",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "ClientContact",
                table: "Client",
                nullable: false,
                oldClrType: typeof(string),
                oldMaxLength: 100);

            migrationBuilder.AddColumn<string>(
                name: "ClientRepresentative",
                table: "Client",
                maxLength: 100,
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProjectEstBeginDate",
                table: "Project");

            migrationBuilder.DropColumn(
                name: "ProjectEstEndDate",
                table: "Project");

            migrationBuilder.DropColumn(
                name: "ClientRepresentative",
                table: "Client");

            migrationBuilder.RenameColumn(
                name: "ProjectActBeginDate",
                table: "Project",
                newName: "ProjectActStartDate");

            migrationBuilder.AlterColumn<string>(
                name: "ClientContact",
                table: "Client",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string));

            migrationBuilder.AddColumn<long>(
                name: "Phone",
                table: "Client",
                nullable: false,
                defaultValue: 0L);
        }
    }
}
