﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace NBD.Migrations
{
    public partial class addingrole : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PayrateCPH",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "PayratePPH",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "Role",
                table: "Personnels");

            migrationBuilder.AddColumn<int>(
                name: "RoleID",
                table: "Personnels",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    RoleName = table.Column<string>(maxLength: 100, nullable: false),
                    PayrateCPH = table.Column<float>(nullable: false),
                    PayratePPH = table.Column<float>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.ID);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Personnels_RoleID",
                table: "Personnels",
                column: "RoleID");

            migrationBuilder.AddForeignKey(
                name: "FK_Personnels_Role_RoleID",
                table: "Personnels",
                column: "RoleID",
                principalTable: "Role",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Personnels_Role_RoleID",
                table: "Personnels");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropIndex(
                name: "IX_Personnels_RoleID",
                table: "Personnels");

            migrationBuilder.DropColumn(
                name: "RoleID",
                table: "Personnels");

            migrationBuilder.AddColumn<float>(
                name: "PayrateCPH",
                table: "Personnels",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<float>(
                name: "PayratePPH",
                table: "Personnels",
                nullable: false,
                defaultValue: 0f);

            migrationBuilder.AddColumn<string>(
                name: "Role",
                table: "Personnels",
                maxLength: 30,
                nullable: true);
        }
    }
}
