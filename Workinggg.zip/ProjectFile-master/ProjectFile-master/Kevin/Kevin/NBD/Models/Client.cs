﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace NBD.Models
{
    public class Client
    {
        public int ID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "You cannot leave the client name blank.")]
        [StringLength(100, ErrorMessage = "Client name cannot be more than 100 characters long.")]
        public string ClientName { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "You cannot leave the client address blank.")]
        [StringLength(1000, ErrorMessage = "Client address cannot be more than 1000 characters long.")]
        public string ClientAddress { get; set; }

        //[Display(Name = "City")]
        //[Required(ErrorMessage = "You cannot leave the client city blank.")]
        //[StringLength(100, ErrorMessage = "Client city cannot be more than 100 characters long.")]
        //public string ClientCity { get; set; }

        [Display(Name = "Contact")]
        [Required(ErrorMessage = "Phone number is required.")]
        //[RegularExpression("^\\d{10}$", ErrorMessage = "Please enter a valid 10-digit phone number (no spaces).")]
        [DataType(DataType.PhoneNumber)]
        [DisplayFormat(DataFormatString = "{0:(###) ###-####}", ApplyFormatInEditMode = false)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string ClientContact { get; set; }


        [Display(Name = "Representative")]
        [Required(ErrorMessage = "You cannot leave the client contact name blank.")]
        [StringLength(100, ErrorMessage = "Client contact name cannot be more than 100 characters long.")]
        public string ClientRepresentative { get; set; }

        [Display(Name = "Role")]
        [Required(ErrorMessage = "You cannot leave the client contact role blank.")]
        [StringLength(50, ErrorMessage = "Client name cannot be more than 50 characters long.")]
        public string ClientRole { get; set; }

        public ICollection<Project> projects { get; set; }
        
            //public int ProjectId { get; set; }
            //public Project project { get; set; }
 }
}
