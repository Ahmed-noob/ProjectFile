﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace NBD.Models
{
    public class Project:IValidatableObject
    {
        public Project()
        {
            hours = new HashSet<WorkSheet>();

            teams = new HashSet<ProjectPersonnel>();

        }
        public int ID { get; set; }
        //Name---------------------------------------
        [Display(Name = "Name")]
        [Required(ErrorMessage = "You cannot leave the project name blank.")]
        [StringLength(50, ErrorMessage = "Project name cannot be more than 50 characters long.")]
        public string ProjectName { get; set; }
        //--------------------------------------------
        
        //Site----------------------------------------
        [Display(Name = "Site")]
        [Required(ErrorMessage = "You cannot leave the project site blank.")]
        [StringLength(500, ErrorMessage = "Project site cannot be more than 500 characters long.")]
        public string ProjectSite { get; set; }
        //---------------------------------------------

            //----ActUalAmmount-----
        [Display(Name = "Actual Amount")]
        [DataType(DataType.Currency)]
        public float? ProjectBidActAmt { get; set; }

        //ProjectActualBeginDate---------------------------------
        [Display(Name = "Actual Start Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ProjectActBeginDate { get; set; }
        //---------------------------------------------

        //ProAEndDate----------------------------------
        [Display(Name = "Actual End Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime ProjectActEndDate { get; set; }
        //---------------------------------------------


        ////ProEBeginDate----------------------------------
        //[Display(Name = "Estimated Begin Date")]
        //[DataType(DataType.Date)]
        //[Required(ErrorMessage = "You must enter the end date of project.")]
        //[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        //public string ProjectEstBeginDate { get; set; }
        ////----------------------------------------------

        ////ProEEndDate----------------------------------
        //[Display(Name = "Estimated End Date")]
        //[DataType(DataType.Date)]
        //[Required(ErrorMessage = "You must enter the end date of project.")]
        //[DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        //public string ProjectEstEndDate { get; set; }
        //----------------------------------------------
        public int ClientID { get; set; }
        public Client client { get; set; }
        public ICollection<Bid> bids { get; set; }

       public ICollection<ProjectPersonnel> teams { get; set; }
        public ICollection<WorkSheet> hours { get; set; }



        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {

            if (ProjectActBeginDate > ProjectActEndDate)
            {
                yield return new ValidationResult("The Begin Date Entered Does Notb Correspond well With the End Dates");
            }
          

        }
    }
}
