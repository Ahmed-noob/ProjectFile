﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NBD.Models
{
    public class WorkSheet
    {
        //public float? ExtendedCost
        //{
        //    get
        //    {
        //        return 

        //    }
        
    public int ProjectID { get; set; }
        public Project project { get; set; }

        public int PersonnelID { get; set; }
        public Personnel personnel { get; set; }
        public string Task { get; set; }

        [Display(Name = "Hours")]
        [Required(ErrorMessage = " Hours is required.")]
        public Int64 Hours { get; set; }
    }
}

