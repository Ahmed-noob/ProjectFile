﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NBD.Models
{
    public class Role
    {
        public int ID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "You cannot leave the client name blank.")]
        [StringLength(100, ErrorMessage = "Client name cannot be more than 100 characters long.")]
        public string RoleName { get; set; }

        [Display(Name = "Payrate (Cost)")]
        [Required(ErrorMessage = "Payrate (Cost) Amount is required.")]
        [DataType(DataType.Currency)]
        public float? PayrateCPH { get; set; }

        [Display(Name = "Payrate (Price)")]
        [Required(ErrorMessage = "Payrate (Price) Amount is required.")]
        [DataType(DataType.Currency)]
        public float? PayratePPH { get; set; }

        public ICollection<Personnel> Personnels { get; set; }

    }
}
