﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace NBD.Models
{
    public class Personnel
    {
        public Personnel()
        {
            teams = new HashSet<ProjectPersonnel>();
        }

        //public string rolerep
        //{
        //    get
        //    {
        //        return role.RoleName;
        //    }
        //}
        public int ID { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "You cannot leave the  name blank.")]
        [StringLength(20, ErrorMessage = "First Name cannot be more than 20 characters long.")]
        public string PersonnelFirstName { get; set; }

        [Display(Name = "Middle Name")]
        [StringLength(20, ErrorMessage = "Middle name cannot be more than 20 characters long.")]
        public string PersonnelMiddleName { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "You cannot leave the last name blank.")]
        [StringLength(20, ErrorMessage = "Last name cannot be more than 20 characters long.")]
        public string PersonnelLastName { get; set; }

        public string PersonnelFullName { get { return PersonnelFirstName + ' ' + PersonnelLastName; } }

        [Display(Name = "Phone Number")]
        [Required(ErrorMessage = "Phone number is required.")]
        //[RegularExpression("^\\d{10}$", ErrorMessage = "Please enter a valid 10-digit phone number (no spaces).")]
        [DataType(DataType.PhoneNumber)]
        [DisplayFormat(DataFormatString = "{0:(###) ###-####}", ApplyFormatInEditMode = false)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string PersonnelPhone { get; set; }

        [Display(Name = "Email address")]
        [Required(ErrorMessage = "The email address is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "You cannot leave the project site blank.")]
        [StringLength(500, ErrorMessage = "Project site cannot be more than 500 characters long.")]
        public string Address { get; set; }

        [Display(Name = "Team")]
        [StringLength(30, ErrorMessage = "Team name cannot be more than 30 characters long.")]
        public string Team { get; set; }

       
        [Display(Name = "Status")]
        [Required(ErrorMessage = "Personnel status is required.")]
        public string status { get; set; }

        public int RoleID { get; set; }
        public Role role { get; set; }

        //public string PersonnelGender{ get; set; }


        //public string PersonnelAge { get; set; }

        public ICollection<WorkSheet> hours { get; set; }
        public ICollection<ProjectPersonnel> teams { get; set; }
    }
}
