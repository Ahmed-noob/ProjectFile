﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace NBD.Models
{
    public class Bid:IValidatableObject
    {
        public int ID { get; set; }

        [Display(Name = "Estimated Amount")]
        [Required(ErrorMessage = "Bid Estimated Amount is required.")]
        [DataType(DataType.Currency)]
        public float? BidEstAmt { get; set; }

        [Display(Name = "Commit Date")]
        [DataType(DataType.Date)]
        [Required(ErrorMessage = "You must enter the date of bid.")]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime BidDate { get; set; }

        [Display(Name = "NBD Flag")]
        public bool NBDApprovedFlag { get; set; }

        [Display(Name = "Client Flag")]
        public bool ClientApprovedFlag { get; set; }

        [Display(Name = "Estimated Total Hrs")]
        [Required(ErrorMessage = "Estimated Hours is required.")]
        public Int64 Esthours { get; set; }

        [Display(Name = "Estimated Production Workers Hrs")]
        [Required(ErrorMessage = "Estimated Production Workers Hours is required.")]
        public Int64 EstProdWrkhours { get; set; }

        [Display(Name = "Estimated Design Hrs")]
        [Required(ErrorMessage = "Estimated Design Hours is required.")]
        public Int64 EstDesignhours { get; set; }

       [Display(Name = "Bid Estimated Start Date")]
       [DataType(DataType.Date)]
       [Required(ErrorMessage = "You must enter the start date of bid.")]
       [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
       public DateTime BidEstStartDate { get; set; }

       [Display(Name = "Bid Estimated End Date")]
       [DataType(DataType.Date)]
       [Required(ErrorMessage = "You must enter the end date of bid.")]
       [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
       public DateTime BidEstEndDate { get; set; }

        public int ProjectId { get; set; }
        public Project project { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {

            if (BidDate > BidEstStartDate || BidDate < BidEstEndDate)
            {
                yield return new ValidationResult("The Bid Date Entered Does Notb Correspond well With the Other Dates");
            }

            if (BidEstStartDate > BidEstEndDate)
            {
                yield return new ValidationResult("The Bid Estimated Start And End Date Does not go well ");
            }

            if (EstDesignhours < 0)
            {
                yield return new ValidationResult("The Bid Estimated Start And End Date Does not go well ");
            }

            if (EstProdWrkhours < 0)
            {
                yield return new ValidationResult("The Bid Estimated Start And End Date Does not go well ");
            }

            if (Esthours < 0)
            {
                yield return new ValidationResult("The Bid Estimated Start And End Date Does not go well ");
            }

        }





    }
}
