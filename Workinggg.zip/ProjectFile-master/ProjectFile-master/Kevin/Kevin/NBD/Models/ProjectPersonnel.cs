﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NBD.Models
{
    public class ProjectPersonnel
    {
        public int ProjectID { get; set; }
        public Project project { get; set; }

        public int PersonnelID { get; set; }
        public Personnel personnel { get; set; }
    }
}
