﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using NBD.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace NBD.Data
{
    public static class NBDseedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new NaturalByDesignContext(
               serviceProvider.GetRequiredService<DbContextOptions<NaturalByDesignContext>>()))
            {
                if (!context.Client.Any())
                {
                    context.Client.AddRange(
                       new Client
                       {
                           ClientName = "ABC Mallway",
                           ClientAddress = " 7023, Marpin Crt., London",
                           ClientContact = "9325006421",
                           ClientRepresentative = "George Lorry",
                           ClientRole = "Mgr."

                       },

                       new Client
                       {
                           ClientName = "Costco",
                           ClientAddress = "34-A,bay Street, Boston ",
                           ClientContact = "9898676656",
                           ClientRepresentative = "George Lorry",
                           ClientRole = "Mgr."
                       },

                      new Client
                      {
                          ClientName = "CityPoint Center",
                          ClientAddress = " 12th, Carmwood Avn., Brooklyn",
                          ClientContact = "9765549689",
                          ClientRole = "Dsgr.",
                          ClientRepresentative = "Maria Johnson"
                      }

                     );
                    context.SaveChanges();
                }
                    if (!context.Project.Any())
                    {
                        context.Project.AddRange(
                         new Project
                         {
                             ProjectName = "London Sq. Mall",
                             ProjectSite = "4th Blvd. Xiomi",
                             ProjectBidActAmt = 500000,
                             ProjectActEndDate = DateTime.Parse("1955-09-01"),
                             ProjectActBeginDate = DateTime.Parse("1955-10-01"),
                             ClientID = context.Client.FirstOrDefault(d => d.ClientName == "CityPoint Center").ID
                         },

                             new Project
                             {
                                 ProjectName = "Miami Sq. Mall",
                                 ProjectSite = "Volnure rd. downtown",
                                 ProjectBidActAmt = 9000000,
                                 ProjectActEndDate = DateTime.Parse("1956-04-11"),
                                 ProjectActBeginDate = DateTime.Parse("1956-05-01"),
                                 ClientID = context.Client.FirstOrDefault(d => d.ClientName == "Costco").ID

                             },
                             new Project
                             {
                                 ProjectName = "New York Sq. Mall",
                                 ProjectSite = "42nd srt., 5th avn.",
                                 ProjectBidActAmt = 9000000,
                                 ProjectActEndDate = DateTime.Parse("1956-06-03"),
                                 ProjectActBeginDate = DateTime.Parse("1955-07-01"),
                                 ClientID = context.Client.FirstOrDefault(d => d.ClientName == "Costco").ID

                             }
                                          );
                        context.SaveChanges();
                    }
                    //Bids
                    if (!context.Bid.Any())
                    {
                        context.Bid.AddRange(
                        new Bid
                        {
                            BidEstAmt = 1234,
                            BidDate = DateTime.Parse("1955-07-01"),
                            NBDApprovedFlag = true,
                            ClientApprovedFlag = true,
                            Esthours = 45,
                            EstProdWrkhours = 56,
                            EstDesignhours = 30,
                            BidEstStartDate = DateTime.Parse("1955-08-01"),
                            BidEstEndDate = DateTime.Parse("1955-08-23"),
                            ProjectId = context.Project.FirstOrDefault(d => d.ProjectName == "Miami Sq. Mall").ID
                        },
                        new Bid
                        {
                            BidEstAmt = 4565,
                            BidDate = DateTime.Parse("1956-11-11"),
                            NBDApprovedFlag = true,
                            ClientApprovedFlag = true,
                            Esthours = 34,
                            EstProdWrkhours = 45,
                            EstDesignhours = 30,
                            BidEstStartDate = DateTime.Parse("1956-11-13"),
                            BidEstEndDate = DateTime.Parse("1955-11-24"),
                            ProjectId = context.Project.FirstOrDefault(d => d.ProjectName == "new York Sq. Mall").ID
                        });
                        context.SaveChanges();
                    }
                if (!context.Role.Any())
                {
                    context.Role.AddRange(
                    new Role
                    {
                       RoleName = "Admin",
                       PayrateCPH = 677,
                       PayratePPH = 99
                    },
                    new Role
                    {
                        RoleName = "Design",
                        PayrateCPH = 677,
                        PayratePPH = 99
                    });
                    context.SaveChanges();
                }
                if (!context.Personnels.Any())
                {
                    context.Personnels.AddRange(
                    new Personnel
                    {
                       PersonnelFirstName = "Shahrukh",
                       PersonnelMiddleName = "Rukh",
                       PersonnelLastName = "Khan",
                       Address = "800 Niagara St",
                       Email = "rukhkhan@email.com",
                       PersonnelPhone = "9057895623",
                       Team = "Design",
                       status = "Active",
                        RoleID = context.Role.FirstOrDefault(d => d.RoleName == "Admin").ID


                    },
                    new Personnel
                    {
                        PersonnelFirstName = "Jax",
                        PersonnelMiddleName = "Zane",
                        PersonnelLastName = "Kurr",
                        Address = "810 Niagara St",
                        Email = "jaxzane@email.com",
                        PersonnelPhone = "9057824623",
                       
                        Team = "Design",
                        status = "Active",
                        RoleID = context.Role.FirstOrDefault(d => d.RoleName == "Design").ID


                    },
                     new Personnel
                     {
                         PersonnelFirstName = "Kevin",
                         PersonnelMiddleName = "Andres",
                         PersonnelLastName = "Gomez",
                         Address = "850 Niagara St",
                         Email = "kgomez@email.com",
                         PersonnelPhone = "9057845874",
                       
                         Team = "Production",
                         status = "Active",
                         RoleID = context.Role.FirstOrDefault(d => d.RoleName == "Admin").ID


                     },
                     new Personnel
                     {
                         PersonnelFirstName = "James",
                         PersonnelMiddleName = "Patrick",
                         PersonnelLastName = "Stifter",
                         Address = "800 Woodlawn Rd",
                         Email = "Jpatrick@email.com",
                         PersonnelPhone = "9054785222",
                        
                         Team = "Design",
                         status = "Unactive",
                         RoleID = context.Role.FirstOrDefault(d => d.RoleName == "Design").ID


                     }
                    );
                    context.SaveChanges();
                }

            }


            }
        }
    }

