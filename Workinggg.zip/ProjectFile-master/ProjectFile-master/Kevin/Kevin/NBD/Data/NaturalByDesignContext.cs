﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using NBD.Models;

namespace NBD.Data
{
    public class NaturalByDesignContext : DbContext
    {
        public NaturalByDesignContext (DbContextOptions<NaturalByDesignContext> options)
            : base(options)
        {
        }

        public DbSet<NBD.Models.Bid> Bid { get; set; }

        public DbSet<NBD.Models.Client> Client { get; set; }
        public DbSet<NBD.Models.Personnel> Personnels { get; set; }

        public DbSet<NBD.Models.ProjectPersonnel> ProjectPersonnels { get; set; }

        public DbSet<NBD.Models.Project> Project { get; set; }
        public DbSet<NBD.Models.Role> Roles { get; set; }
        public DbSet<NBD.Models.WorkSheet> WorkSheets { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ProjectPersonnel>()
            .HasKey(t => new { t.ProjectID, t.PersonnelID });

            modelBuilder.Entity<WorkSheet>()
           .HasKey(t => new { t.ProjectID, t.PersonnelID });

            modelBuilder.Entity<Personnel>()
          .HasMany<ProjectPersonnel>(t => t.teams)
          .WithOne(c => c.personnel)
          .HasForeignKey(c => c.PersonnelID)
          .OnDelete(DeleteBehavior.Restrict);

        //    modelBuilder.Entity<Personnel>()
        //.HasMany<WorkSheet>(t => t.hours)
        //.WithOne(c => c.personnel)
        //.HasForeignKey(c => c.PersonnelID)
        //.OnDelete(DeleteBehavior.Restrict);
        }

        public DbSet<NBD.Models.Role> Role { get; set; }
    }
}
